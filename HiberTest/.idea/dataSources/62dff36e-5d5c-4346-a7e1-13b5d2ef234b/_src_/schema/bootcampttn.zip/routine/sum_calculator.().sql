CREATE FUNCTION sum_calculator()
  RETURNS INT
  BEGIN DECLARE x INT;  SELECT SUM(salary) as total_salary_account from employee where department='account' INTO x; RETURN (x); END;
