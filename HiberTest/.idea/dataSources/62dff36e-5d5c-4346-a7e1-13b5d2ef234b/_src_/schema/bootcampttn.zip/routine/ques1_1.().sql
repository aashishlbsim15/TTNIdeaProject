CREATE PROCEDURE ques1_1()
  BEGIN select RIGHT(name,1),salary,department,id from employee where name like '%n'; END;
