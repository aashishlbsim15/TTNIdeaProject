CREATE PROCEDURE add_employee(IN name VARCHAR(20), IN salary INT, IN dept VARCHAR(20))
  BEGIN INSERT INTO employee(name,salary,department) VALUES(name,salary,dept); END;
