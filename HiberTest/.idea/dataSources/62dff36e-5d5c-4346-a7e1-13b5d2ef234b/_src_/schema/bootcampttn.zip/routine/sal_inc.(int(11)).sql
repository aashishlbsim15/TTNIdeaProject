CREATE PROCEDURE sal_inc(IN amt INT)
  BEGIN UPDATE employee SET salary=salary+amt WHERE department='sales'; END;
