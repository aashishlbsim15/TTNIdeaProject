CREATE PROCEDURE ques1()
  BEGIN select * from employee where name like '%n';
END;
