CREATE TRIGGER put_changes
AFTER UPDATE ON employee
FOR EACH ROW
  BEGIN if new.salary!=old.salary THEN INSERT INTO triggers_employee SET name=old.name, updated_by="user", changed_salary=new.salary; END IF; END;
